console.log("Youtube Untrend v0.2 loaded");

setInterval(hideIt, 500)

function hideIt() {
  document.getElementById("appbar-nav").children[0].children[1].setAttribute("style", "display:none");
}